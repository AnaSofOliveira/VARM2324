Models required for face detection. Motive to test if any model runs better than Dlib's HOG frontal face detector and if any found then use that model for vision tasks.
