class FaceRecognition:
    def __init__(self):
        pass
    