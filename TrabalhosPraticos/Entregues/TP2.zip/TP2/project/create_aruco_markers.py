from register.Register import Register

Register.generate_aruco_markers()
